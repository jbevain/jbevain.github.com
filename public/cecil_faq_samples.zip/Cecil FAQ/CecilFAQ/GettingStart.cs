using System;

using System.Reflection;

using Mono.Cecil;

namespace CecilFAQ
{
	/// <summary>
	/// Description r�sum�e de Class1.
	/// </summary>
	class GettingStart
	{
		/// <summary>
		/// Point d'entr�e principal de l'application.
		/// </summary>
		[STAThread]
		static void Main()
		{
			//Creates an AssemblyDefinition from the "MyLibrary.dll" assembly
			AssemblyDefinition myLibrary = AssemblyFactory.GetAssembly("MyLibrary.dll");

			//Gets all types which are declared in the Main Module of "MyLibrary.dll"
			foreach(TypeDefinition type in myLibrary.MainModule.Types)
			{
				//Writes the full name of a type
				Console.WriteLine(type.FullName);
			}
			Console.ReadLine();
		}
	}
}
