using System;

using System.Reflection;

using Mono.Cecil;
using Mono.Cecil.Cil;

namespace CecilFAQ
{
	/// <summary>
	/// Description r�sum�e de CecilAOP.
	/// </summary>
	public class CecilAOP
	{
		[STAThread]
		public static void Main()
		{
			//Getting the path of the "MyLibrary.dll" assembly
			string pathBin = "../../../MyLibrary/bin/debug/MyLibrary.dll";

			//Gets the AssemblyDefinition of "MyLibrary"
			AssemblyDefinition assembly = AssemblyFactory.GetAssembly(pathBin);

			//Gets the MethodInfo of Console.WriteLine() method
			MethodInfo writeLineMethod = 
				typeof(Console).GetMethod("WriteLine", new Type[]{typeof(string)});

			//Gets all types of the MainModule of the assembly
			foreach(TypeDefinition type in assembly.MainModule.Types)
			{
				if(type.Name != "<Module>")
				{
					//Gets all methods of the current type
					foreach(MethodDefinition method in type.Methods)
					{
						//Gets the CilWorker of the method for working with MSIL 			
						//instructions
						CilWorker worker = method.Body.CilWorker;

						//Creating a sentence according to the current method
						string sentence;
						sentence = String.Concat("Code added in ", method.Name);

						//Import the Console.WriteLine() method
						MethodReference writeLine;
						writeLine = assembly.MainModule.Import(writeLineMethod);

						//Creates the MSIL instruction for inserting the sentence
						Instruction insertSentence;
						insertSentence = worker.Create(OpCodes.Ldstr, sentence);

						//Creates the MSIL instruction for calling the 
						//Console.WriteLine(string value) method
						Instruction callWriteLine;
						callWriteLine = worker.Create(OpCodes.Call, writeLine);

			
						//Getting the first instruction of the current method
						Instruction ins = method.Body.Instructions[0];

						//Inserts the insertSentence instruction before the first 
						//instruction
						method.Body.CilWorker.InsertBefore(ins, insertSentence);

						//Inserts the callWriteLineMethod after the 
						//insertSentence instruction
						worker.InsertAfter(insertSentence, callWriteLine);
					}
					//Import the modifying type into the AssemblyDefinition of 
					//"MyLibrary"
					assembly.MainModule.Import(type);
				}	
			}

			//Save the modified "MyLibrary" assembly
			AssemblyFactory.SaveAssembly(assembly, pathBin);

			Console.WriteLine("The library : " + pathBin + " is modified");
			Console.ReadLine();
		}
	}
}
