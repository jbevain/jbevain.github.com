using System;

namespace TestMyLibrary
{
	/// <summary>
	/// Description r�sum�e de Class1.
	/// </summary>
	class Program
	{
		/// <summary>
		/// Point d'entr�e principal de l'application.
		/// </summary>
		[STAThread]
		static void Main(string[] args)
		{
			MyLibrary.Person p = new MyLibrary.Person();
			p.Name = "Harry May";
			p.Birthday = new DateTime(1982, 01, 26);
			int age = p.GetAge();
			Console.ReadLine();
		}
	}
}
