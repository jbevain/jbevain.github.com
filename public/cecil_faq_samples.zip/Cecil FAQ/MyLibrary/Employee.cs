using System;

namespace MyLibrary
{
	/// <summary>
	/// Description r�sum�e de Employee.
	/// </summary>
	public class Employee
	{
		public Employee()
		{
			//
			// TODO�: ajoutez ici la logique du constructeur
			//
		}
	}
}
