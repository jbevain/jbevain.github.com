using System;

namespace MyLibrary
{
	/// <summary>
	/// Description r�sum�e de Person.
	/// </summary>
	public class Person
	{
		#region Attributes

		private string _name;
		private DateTime _birthday;

		#endregion

		#region Constructors

		public Person(string name, DateTime birthday)
		{
			_name = name;
			_birthday = birthday;
		}

		public Person() : this(String.Empty, DateTime.Now)
		{

		}

		#endregion

		#region Methods

		public int GetAge()
		{
			return DateTime.Now.Year - _birthday.Year;
		}

		#endregion

		#region Properties

		public string Name
		{
			get
			{
				return _name;
			}
			set
			{
				_name = value;
			}
		}

		public DateTime Birthday
		{
			get
			{
				return _birthday;
			}
			set
			{
				_birthday = value;
			}
		}

		#endregion
	}
}
