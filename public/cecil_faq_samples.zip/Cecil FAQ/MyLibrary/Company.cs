using System;

namespace MyLibrary
{
	/// <summary>
	/// Description r�sum�e de Company.
	/// </summary>
	public class Company
	{
		public Company()
		{
			//
			// TODO�: ajoutez ici la logique du constructeur
			//
		}
	}
}
