// Tests.cs

using System;
using NUnit.Framework;

// dummy complex system, may have been generated
public class ComplexSystem {
    public int m_secret;
    public void SecretOperation(int oper) {}
    public int PublicOperation() { return 0; }
}

[TestFixture]
public class TestComplexSystem {
    
    private ComplexSystem m_complexSystem;
        
    [SetUp]
    public void SetUp() {
        m_complexSystem = new ComplexSystem();
    }
    
    [Test]
    public void TestPublicOperation() {
        Assert.AreEqual(0, m_complexSystem.PublicOperation() % 2);
        m_complexSystem.SecretOperation(1);
        m_complexSystem.SecretOperation(1);
        m_complexSystem.SecretOperation(1);
        Assert.AreEqual(0, m_complexSystem.PublicOperation() % 2);
        Assert.AreEqual(4, m_complexSystem.PublicOperation());
    }
    
    [Test]
    public void TestFieldSecret() {
        Assert.AreEqual(0, m_complexSystem.m_secret);
        m_complexSystem.SecretOperation(1);
        Assert.AreEqual(1, m_complexSystem.m_secret);
    }
    
    [Test]
    public void TestSecretOperation() {
        int cursor = m_complexSystem.m_secret;
        m_complexSystem.SecretOperation(12);
        Assert.AreEqual(12, m_complexSystem.m_secret - cursor);
    }
}
