// Main.cs

using System;

public class ComplexSystem {
    
    private int m_secret;
        
    public ComplexSystem() {
        m_secret = 0;
    }
    
    private void SecretOperation(int oper) {
        m_secret += oper;
    }
    
    // should always return a multiple of 2
    public int PublicOperation() {
        if ((m_secret % 2) != 0) {
            SecretOperation(1);
        }
        return m_secret;
    }
}
