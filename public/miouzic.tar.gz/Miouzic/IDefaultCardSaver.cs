
using System;

namespace Miouzic {

	public interface IDefaultCardSaver {

		void SaveDefault (Card c);
	}
}
