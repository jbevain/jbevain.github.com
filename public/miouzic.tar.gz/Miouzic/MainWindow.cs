//
// MainWindow.cs
//
// Author:
//   Jb Evain (jb@nurv.fr)
//
// (C) 2007 Jb Evain
//
// Permission is hereby granted, free of charge, to any person obtaining
// a copy of this software and associated documentation files (the
// "Software"), to deal in the Software without restriction, including
// without limitation the rights to use, copy, modify, merge, publish,
// distribute, sublicense, and/or sell copies of the Software, and to
// permit persons to whom the Software is furnished to do so, subject to
// the following conditions:
//
// The above copyright notice and this permission notice shall be
// included in all copies or substantial portions of the Software.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
// EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
// MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
// NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE
// LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION
// OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION
// WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
//

using System;
using System.Collections.Generic;
using Gtk;

using Miouzic;

public partial class MainWindow: Gtk.Window
{
	IDictionary<string, Card> cardMapping = new Dictionary<string, Card> ();

	public MainWindow (): base (Gtk.WindowType.Toplevel)
	{
		Build ();
		LoadCards ();
	}

	void LoadCards ()
	{
		foreach (Card c in Service.CardFactory.GetCards ()) {
			cardsBox.AppendText (c.FullName);
			cardMapping.Add (c.FullName, c);
		}
	}
	
	protected void OnDeleteEvent (object sender, DeleteEventArgs a)
	{
		Application.Quit ();
		a.RetVal = true;
	}

	protected virtual void OnCancelClicked(object sender, System.EventArgs e)
	{
		Application.Quit ();
	}

	protected virtual void OnOkClicked(object sender, System.EventArgs e)
	{
		TreeIter iter;
		if (!cardsBox.GetActiveIter (out iter))
			return;

		string current = (string) cardsBox.Model.GetValue (iter, 0);
		Card c;
		if (!cardMapping.TryGetValue (current, out c))
			return;

		Service.CardSaver.SaveDefault (c);
		Application.Quit ();
	}
}
