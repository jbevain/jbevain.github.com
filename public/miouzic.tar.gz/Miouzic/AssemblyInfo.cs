using System.Reflection;
using System.Runtime.CompilerServices;

[assembly: AssemblyTitle("Miouzic")]
[assembly: AssemblyDescription("An application to change the default ALSA card")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("nurv")]
[assembly: AssemblyProduct("Miouzic")]
[assembly: AssemblyCopyright("(C) 2007 nurv")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]

[assembly: AssemblyVersion("1.0.0.0")]

[assembly: AssemblyDelaySign(false)]
[assembly: AssemblyKeyFile("")]
