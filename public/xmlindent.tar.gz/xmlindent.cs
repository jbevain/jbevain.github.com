//
// xmlindent.cs
//
// Author:
//   Jb Evain  <jbevain@gmail.com>
//
// Copyright (C) 2005 Jb Evain
//
// Permission is hereby granted, free of charge, to any person obtaining
// a copy of this software and associated documentation files (the
// "Software"), to deal in the Software without restriction, including
// without limitation the rights to use, copy, modify, merge, publish,
// distribute, sublicense, and/or sell copies of the Software, and to
// permit persons to whom the Software is furnished to do so, subject to
// the following conditions:
// 
// The above copyright notice and this permission notice shall be
// included in all copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
// EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
// MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
// NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE
// LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION
// OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION
// WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
//

using System;
using System.IO;
using System.Text;
using System.Xml;

class XmlIndent {

	static void Main (string [] args)
	{
		if (args.Length == 0) {
			Usage ();
			return;
		}

		FileInfo fi = new FileInfo (args [0]);
		if (!fi.Exists) {
			Usage ();
			Console.WriteLine ("\nfile not found: {0}", fi.Name);
		}

		try {
			using (FileStream fsi = fi.OpenRead ()) {
				using (StreamReader sr = new StreamReader (fsi)) {
					if (args.Length > 1) {
						FileInfo fo = new FileInfo (args [1]);
						using (StreamWriter sw = fo.CreateText ())
							PrettyPrintXml (sr, sw);
					} else
						PrettyPrintXml (sr, Console.Out);
				}
			}
		} catch (Exception e) {
			Usage ();
			Console.WriteLine ("\nSomething got wrong:\n {0}", e);
		}
	}

	static void PrettyPrintXml (StreamReader reader, TextWriter writer)
	{
		XmlTextWriter xw = new XmlTextWriter (writer);
		xw.Formatting = Formatting.Indented;
		XmlDocument doc = new XmlDocument ();
		doc.Load (reader);
		doc.Save (xw);
	}

	static void Usage ()
	{
		Console.WriteLine ("An Xml Pretty Printer, usage:\nmono xmlindent.exe file [target]");
	}
}
