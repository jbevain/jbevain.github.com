//
// Author:
//   Jb Evain (jbevain@gmail.com)
//
// (C) 2005 Jb Evain
//

namespace Levenshtein {

	using System;

	using NUnit.Framework;
	
	[TestFixture]
	public class Tests {
		
		[Test]
		public void Test ()
		{
			string az = "azerty", qw = "qwerty";
			Assert.AreEqual (az.Length, Distance.GetDistance (az, string.Empty));
			Assert.AreEqual (az.Length, Distance.GetDistance (string.Empty, az));
			Assert.AreEqual (2, Distance.GetDistance (az, qw));
			Assert.AreEqual (2, Distance.GetDistance (qw, az));
		}
	}
}
