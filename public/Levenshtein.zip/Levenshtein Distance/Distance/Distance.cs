//
// Author:
//   Jb Evain (jbevain@gmail.com)
//
// (C) 2005 Jb Evain
//

namespace Levenshtein 
{
	public class Distance {
    
		public static int GetDistance (string s, string t)
		{
			// step 1
			int [,] matrix;
			int n = s.Length, m = t.Length;
			if (n == 0)
				return m;
			if (m == 0)
				return n;
        
			matrix = new int [n + 1, m + 1];
        
			// step 2
			for (int i = 0; i <= n; i++)
				matrix [i, 0] = i;
        
			for (int i = 0; i <= m; i++)
				matrix [0, i] = i;
        
			// step 3
			for (int i = 1; i <= n; i++) {
            
				// step 4
				for (int j = 1; j <= m; j++) {
                
					// step 5
					int cost;
					if (s [i - 1] != t [j - 1])
						cost = 1;
					else
						cost = 0;
                
					// step 6
                
					matrix [i, j] = Min (
						matrix [i - 1, j] + 1,
						matrix [i, j - 1] + 1,
						matrix [i - 1, j - 1] + cost);
				}
			}
			return matrix [n, m];
		}
    
		static int Min (int a, int b, int c)
		{
			int m = a;
			if (b < m)
				m = b;
			if (c < m)
				m = c;
			return m;
		}
	}
}